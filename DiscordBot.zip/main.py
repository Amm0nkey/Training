import discord
from discord.ext import commands
import music


client = commands.Bot(command_prefix = '+')
channel = client.get_channel(888596644709421106)

@client.event
async def on_ready():
  print('bot is ready.')

cogs = [music]

for i in range(len(cogs)):
  cogs[i].setup(client)


with open('badwords.txt') as badfile:
  badfile = badfile.read().split()

@client.command()
async def hugs(ctx):
  await ctx.send(f' *Hugs {ctx.author.name} tightly*')

@client.event
async def on_message(message):
  for badword in badfile:
    if badword in message.content.lower():
      await message.delete()
      await message.channel.send('Lord Ammonkey sends his regards...')
      client.dispatch('profanity', message, badword)
      return
  await client.process_commands(message)


@client.command(name= 'hello', description= 'greet the user')
async def hello(ctx):
  if ctx.author.name == 'Ammonkey':
    await  ctx.send(f'I bow to Lord {ctx.author.name} my creator and king...')
  else:
    await ctx.send(f' Ammonkey sends his regards {ctx.author.name}')


client.run('ODkwMzAwNzIyMjU4NzcyMDQ4.YUtzKQ.EuVLxOcuYEAOPYNoP7SHUrioReE')